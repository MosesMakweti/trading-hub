// src/shared/confluence-eligibility.ts
function isConfluenceEligible(applicability, direction) {
  if (direction == null) return !1;
  let a = applicability ?? "BOTH";
  return a === "BOTH" || direction === "LONG" && a === "BULLISH" || direction === "SHORT" && a === "BEARISH";
}

// src/shared/draft.ts
var EMPTY_DRAFT = {
  strategyId: null,
  direction: null,
  selectedSession: null,
  selectedEntryModel: null,
  selectedConfluenceIds: [],
  selectedExecutionIds: [],
  plannedEntry: "",
  plannedStopLoss: "",
  plannedTargets: [],
  marketContext: "",
  areasOfInterest: "",
  reasonForTrade: "",
  mediaAssetId: null,
  originSymbol: null,
  acknowledgedSymbolMismatch: null,
  updatedAt: 0
};
function selectStrategy(draft, strategyId, now = Date.now) {
  return draft.strategyId === strategyId ? draft : {
    ...draft,
    strategyId,
    selectedSession: null,
    selectedEntryModel: null,
    selectedConfluenceIds: [],
    selectedExecutionIds: [],
    updatedAt: now()
  };
}
function setDirection(draft, direction, confluencesById2, now = Date.now) {
  let selectedConfluenceIds = draft.selectedConfluenceIds.filter((id) => {
    let confluence = confluencesById2.get(id);
    return confluence ? isConfluenceEligible(confluence.directionApplicability, direction) : !0;
  });
  return { ...draft, direction, selectedConfluenceIds, updatedAt: now() };
}
function toggle(ids, id) {
  return ids.includes(id) ? ids.filter((existing) => existing !== id) : [...ids, id];
}
function toggleConfluence(draft, confluenceId, now = Date.now) {
  return { ...draft, selectedConfluenceIds: toggle(draft.selectedConfluenceIds, confluenceId), updatedAt: now() };
}
function toggleExecution(draft, executionId, now = Date.now) {
  return { ...draft, selectedExecutionIds: toggle(draft.selectedExecutionIds, executionId), updatedAt: now() };
}
function setSession(draft, sessionName, now = Date.now) {
  return { ...draft, selectedSession: sessionName, updatedAt: now() };
}
function setEntryModel(draft, entryModelName, now = Date.now) {
  return { ...draft, selectedEntryModel: entryModelName, updatedAt: now() };
}
function setPlannedEntry(draft, value, now = Date.now) {
  return { ...draft, plannedEntry: value, updatedAt: now() };
}
function setPlannedStopLoss(draft, value, now = Date.now) {
  return { ...draft, plannedStopLoss: value, updatedAt: now() };
}
var defaultIdGen = () => crypto.randomUUID();
function addTarget(draft, now = Date.now, idGen = defaultIdGen) {
  let target = { id: idGen(), label: `TP${draft.plannedTargets.length + 1}`, targetPrice: "" };
  return { ...draft, plannedTargets: [...draft.plannedTargets, target], updatedAt: now() };
}
function removeTarget(draft, targetId, now = Date.now) {
  return { ...draft, plannedTargets: draft.plannedTargets.filter((t) => t.id !== targetId), updatedAt: now() };
}
function updateTarget(draft, targetId, patch, now = Date.now) {
  return {
    ...draft,
    plannedTargets: draft.plannedTargets.map((t) => t.id === targetId ? { ...t, ...patch } : t),
    updatedAt: now()
  };
}
function setNote(draft, field, value, now = Date.now) {
  return { ...draft, [field]: value, updatedAt: now() };
}
function applyPlanSuggestion(draft, suggestion, now = Date.now, idGen = () => crypto.randomUUID()) {
  let next = draft;
  if (suggestion.entry != null && (next = setPlannedEntry(next, suggestion.entry, now)), suggestion.stopLoss != null && (next = setPlannedStopLoss(next, suggestion.stopLoss, now)), suggestion.targets.length > 0) {
    let targets = [...suggestion.targets].sort((a, b) => a.order - b.order).map((t, i) => ({ id: idGen(), label: `TP${i + 1}`, targetPrice: t.price }));
    next = { ...next, plannedTargets: targets, updatedAt: now() };
  }
  return next;
}
function setMediaAssetId(draft, mediaAssetId, now = Date.now) {
  return { ...draft, mediaAssetId, updatedAt: now() };
}
function resetAfterSave(draft, now = Date.now) {
  return {
    ...draft,
    selectedConfluenceIds: [],
    selectedExecutionIds: [],
    plannedEntry: "",
    plannedStopLoss: "",
    plannedTargets: [],
    marketContext: "",
    areasOfInterest: "",
    reasonForTrade: "",
    mediaAssetId: null,
    // Step 9, Part 8 — the just-saved idea is done; the NEXT idea should
    // re-lock onto whatever the chart shows THEN, not carry forward a
    // now-irrelevant origin/acknowledgment pair.
    originSymbol: null,
    acknowledgedSymbolMismatch: null,
    updatedAt: now()
  };
}
function hasMaterialDraftContent(draft) {
  return draft.strategyId != null || draft.direction != null || draft.selectedSession != null || draft.selectedEntryModel != null || draft.selectedConfluenceIds.length > 0 || draft.selectedExecutionIds.length > 0 || draft.plannedEntry.trim().length > 0 || draft.plannedStopLoss.trim().length > 0 || draft.plannedTargets.length > 0 || draft.marketContext.trim().length > 0 || draft.areasOfInterest.trim().length > 0 || draft.reasonForTrade.trim().length > 0 || draft.mediaAssetId != null;
}
function ensureOriginSymbol(draft, currentSymbol, now = Date.now) {
  return draft.originSymbol != null || currentSymbol == null || !hasMaterialDraftContent(draft) ? draft : { ...draft, originSymbol: currentSymbol, updatedAt: now() };
}
function acknowledgeSymbolMismatch(draft, currentSymbol, now = Date.now) {
  return { ...draft, acknowledgedSymbolMismatch: currentSymbol, updatedAt: now() };
}
function startNewIdeaForSymbol(draft, currentSymbol, now = Date.now) {
  return { ...resetAfterSave(draft, now), originSymbol: currentSymbol, updatedAt: now() };
}
function validateDraft(draft, confluences, entryModels = []) {
  let strategyRequired = draft.strategyId == null, directionRequired = draft.direction == null, entryModelRequired = entryModels.length > 0 && draft.selectedEntryModel == null, missingMandatoryConfluenceIds = draft.direction == null ? [] : confluences.filter((c) => c.mandatory && isConfluenceEligible(c.directionApplicability, draft.direction)).filter((c) => !draft.selectedConfluenceIds.includes(c.id)).map((c) => c.id);
  return {
    strategyRequired,
    directionRequired,
    entryModelRequired,
    missingMandatoryConfluenceIds,
    ready: !strategyRequired && !directionRequired && !entryModelRequired && missingMandatoryConfluenceIds.length === 0
  };
}

// src/shared/asset-compatibility.ts
function isAssetCompatible(displaySymbol, applicableAssets) {
  if (applicableAssets.length === 0) return !0;
  let normalized = displaySymbol.trim().toUpperCase();
  return applicableAssets.some((asset) => asset.trim().toUpperCase() === normalized);
}

// src/shared/date-key.ts
function localDateToKey(date) {
  let y = date.getFullYear(), m = String(date.getMonth() + 1).padStart(2, "0"), d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

// src/shared/trade-payload.ts
var DEFAULT_EXECUTION_MINUTES = 570, DEFAULT_HIGHER_TIMEFRAME_BIAS = "BULLISH", DEFAULT_BIAS_CONFIDENCE_PERCENT = 50;
function parsePrice(raw) {
  let trimmed = raw.trim();
  if (trimmed.length === 0) return { status: "empty" };
  let value = Number(trimmed);
  return Number.isFinite(value) ? { status: "ok", value } : { status: "invalid" };
}
function buildCreateTradePayload(params) {
  let { draft, chartContext, strategy, now = () => /* @__PURE__ */ new Date() } = params, blockers = [], warnings = [];
  draft.direction == null && blockers.push({ reason: "direction_required", message: "Direction required." });
  let displaySymbol = draft.originSymbol ?? chartContext?.symbol?.display ?? null;
  displaySymbol || blockers.push({ reason: "no_symbol", message: "No symbol detected on the chart." }), draft.strategyId != null && strategy == null && blockers.push({ reason: "strategy_not_loaded", message: "Strategy reference is not loaded yet." }), displaySymbol && strategy && !isAssetCompatible(displaySymbol, strategy.applicableAssets) && blockers.push({ reason: "asset_incompatible", message: `${displaySymbol} is not configured for this strategy.` });
  let confluenceNames = [];
  if (draft.selectedConfluenceIds.length > 0)
    if (!strategy)
      blockers.push({ reason: "unresolved_confluence", message: "Selected confluences could not be verified \u2014 strategy not loaded." });
    else
      for (let id of draft.selectedConfluenceIds) {
        let match = strategy.confluences.find((c) => c.id === id);
        match ? isConfluenceEligible(match.directionApplicability, draft.direction) ? confluenceNames.push(match.name) : blockers.push({ reason: "unresolved_confluence", message: "A selected confluence is no longer eligible for the current direction." }) : blockers.push({ reason: "unresolved_confluence", message: "A selected confluence no longer exists on this strategy." });
      }
  let executionNames = [];
  if (draft.selectedExecutionIds.length > 0)
    if (!strategy)
      blockers.push({ reason: "unresolved_execution", message: "Selected execution confirmations could not be verified \u2014 strategy not loaded." });
    else
      for (let id of draft.selectedExecutionIds) {
        let match = strategy.execution.find((c) => c.id === id);
        match ? executionNames.push(match.name) : blockers.push({ reason: "unresolved_execution", message: "A selected execution confirmation no longer exists on this strategy." });
      }
  draft.selectedSession && strategy && !strategy.sessions.some((s) => s.name === draft.selectedSession) && blockers.push({ reason: "unresolved_session", message: "Selected session no longer exists on this strategy." }), draft.selectedEntryModel && strategy && !strategy.entryModels.includes(draft.selectedEntryModel) && blockers.push({ reason: "unresolved_entry_model", message: "Selected entry model no longer exists on this strategy." });
  let entry = parsePrice(draft.plannedEntry);
  entry.status === "empty" && blockers.push({ reason: "entry_required", message: "Planned entry required." }), entry.status === "invalid" && blockers.push({ reason: "entry_invalid", message: "Planned entry must be a valid number." });
  let stopLoss = parsePrice(draft.plannedStopLoss);
  stopLoss.status === "empty" && blockers.push({ reason: "stop_loss_required", message: "Planned stop loss required." }), stopLoss.status === "invalid" && blockers.push({ reason: "stop_loss_invalid", message: "Planned stop loss must be a valid number." });
  let targets = [], anyTargetInvalid = !1, order = 1;
  for (let t of draft.plannedTargets) {
    let parsed = parsePrice(t.targetPrice);
    if (parsed.status !== "empty") {
      if (parsed.status === "invalid" || t.label.trim().length === 0) {
        anyTargetInvalid = !0;
        continue;
      }
      targets.push({ targetOrder: order++, label: t.label.trim(), targetPrice: parsed.value });
    }
  }
  if (anyTargetInvalid && blockers.push({ reason: "target_invalid", message: "One or more targets has an invalid price or label." }), targets.length === 0 && blockers.push({ reason: "targets_required", message: "At least one target is required." }), draft.direction != null && entry.status === "ok" && stopLoss.status === "ok" && ((draft.direction === "LONG" ? entry.value > stopLoss.value : stopLoss.value > entry.value) || warnings.push(
    draft.direction === "LONG" ? "Stop loss should be below entry for a LONG." : "Stop loss should be above entry for a SHORT."
  )), blockers.length > 0 || !displaySymbol || draft.direction == null || entry.status !== "ok" || stopLoss.status !== "ok" || targets.length === 0)
    return { payload: null, blockers, warnings };
  let trade = {
    assetSymbol: displaySymbol,
    executionMinutes: DEFAULT_EXECUTION_MINUTES,
    direction: draft.direction,
    higherTimeframeBias: DEFAULT_HIGHER_TIMEFRAME_BIAS,
    biasConfidencePercent: DEFAULT_BIAS_CONFIDENCE_PERCENT
  };
  draft.strategyId && (trade.strategyId = draft.strategyId), draft.selectedSession && (trade.selectedSession = draft.selectedSession), draft.selectedEntryModel && (trade.selectedEntryModel = draft.selectedEntryModel), confluenceNames.length > 0 && (trade.selectedConfluences = confluenceNames), executionNames.length > 0 && (trade.selectedExecution = executionNames);
  let plan = { entry: entry.value, stopLoss: stopLoss.value, targets };
  chartContext?.timeframe && (plan.timeframe = chartContext.timeframe);
  let notes = {};
  return draft.marketContext.trim() && (notes.marketContext = draft.marketContext.trim()), draft.areasOfInterest.trim() && (notes.areasOfInterest = draft.areasOfInterest.trim()), draft.reasonForTrade.trim() && (notes.reasonForTrade = draft.reasonForTrade.trim()), {
    payload: {
      dateKey: localDateToKey(now()),
      trade,
      plan,
      notes: Object.keys(notes).length > 0 ? notes : void 0,
      // Step 8, §21 — omitted entirely (never sent as null/undefined-in-body)
      // when no screenshot was uploaded, matching `apiCreateTradeSchema`'s
      // own optional field exactly.
      ...draft.mediaAssetId ? { mediaAssetId: draft.mediaAssetId } : {}
    },
    blockers: [],
    warnings
  };
}

// src/shared/config.ts
var API_BASE_URL = "https://traditorium.com";

// src/shared/recognition-suggestions.ts
function findValue(fields, type) {
  return fields.find((f) => f.fieldType === type)?.detectedValue ?? null;
}
function isTradeDirection(value) {
  return value === "LONG" || value === "SHORT";
}
function toPlanSuggestion(outcome) {
  if (outcome.status === "RECOGNITION_FAILED")
    return { symbol: null, timeframe: null, direction: null, entry: null, stopLoss: null, targets: [], isEmpty: !0 };
  let { fields } = outcome, direction = findValue(fields, "DIRECTION"), targets = fields.filter((f) => f.fieldType === "TARGET" && f.detectedValue).map((f) => ({ order: f.targetOrder ?? 1, price: f.detectedValue })).sort((a, b) => a.order - b.order), suggestion = {
    symbol: findValue(fields, "SYMBOL"),
    timeframe: findValue(fields, "TIMEFRAME"),
    direction: isTradeDirection(direction) ? direction : null,
    entry: findValue(fields, "ENTRY"),
    stopLoss: findValue(fields, "STOP_LOSS"),
    targets,
    isEmpty: !1
  };
  return suggestion.isEmpty = suggestion.symbol == null && suggestion.timeframe == null && suggestion.direction == null && suggestion.entry == null && suggestion.stopLoss == null && suggestion.targets.length === 0, suggestion;
}

// src/panel/view.ts
function toChartViewModel(state) {
  if (!state.tradingViewDetected)
    return { show: !1, symbolText: null, timeframeText: null, unavailableLabel: null };
  let ctx = state.chartContext;
  return !ctx || !ctx.detected ? { show: !0, symbolText: null, timeframeText: null, unavailableLabel: "Chart context unavailable" } : {
    show: !0,
    symbolText: ctx.symbol?.display ?? "Symbol unavailable",
    timeframeText: ctx.timeframe ?? "Timeframe unavailable",
    unavailableLabel: null
  };
}
function toViewModel(state) {
  let { connection, tradingViewDetected } = state, base = {
    tvLabel: tradingViewDetected ? "TradingView detected" : "Open TradingView to use the trading companion.",
    tvOn: tradingViewDetected,
    chart: toChartViewModel(state)
  };
  switch (connection.status) {
    case "disconnected":
      return {
        ...base,
        showConnRow: !1,
        connLabel: "",
        connState: "off",
        section: "disconnected",
        userName: "",
        strategyCountLabel: "",
        strategies: [],
        errorMessage: "",
        showFooter: !1
      };
    case "connecting":
      return {
        ...base,
        showConnRow: !0,
        connLabel: "Connecting\u2026",
        connState: "off",
        section: "connecting",
        userName: "",
        strategyCountLabel: "",
        strategies: [],
        errorMessage: "",
        showFooter: !1
      };
    case "error":
      return {
        ...base,
        showConnRow: !1,
        connLabel: "",
        connState: "off",
        section: "error",
        userName: "",
        strategyCountLabel: "",
        strategies: [],
        errorMessage: connection.message,
        showFooter: !1
      };
    case "connected": {
      let count = connection.strategies.length;
      return {
        ...base,
        showConnRow: !0,
        connLabel: "Connected to Traditorium",
        connState: "on",
        section: "connected",
        userName: connection.user.name ?? "Trader",
        strategyCountLabel: `${count} ${count === 1 ? "Strategy" : "Strategies"} available`,
        strategies: connection.strategies,
        errorMessage: "",
        showFooter: !0
      };
    }
  }
}

// src/panel/strategy-loader.ts
function createStrategyLoader(fetchReference, onChange) {
  let latestRequestedId = null;
  return {
    request(strategyId) {
      if (latestRequestedId = strategyId, strategyId == null) {
        onChange({ status: "idle" });
        return;
      }
      onChange({ status: "loading", strategyId }), fetchReference(strategyId).then((result) => {
        latestRequestedId === strategyId && onChange(
          result.ok ? { status: "loaded", strategyId, strategy: result.strategy } : { status: "error", strategyId, message: result.message }
        );
      });
    }
  };
}

// src/panel/strategy-view.ts
function toRow(confluence, selectedIds) {
  return {
    id: confluence.id,
    name: confluence.name,
    category: confluence.category,
    weight: confluence.weight,
    mandatory: confluence.mandatory,
    checked: selectedIds.includes(confluence.id)
  };
}
function toStrategyContextViewModel(params) {
  let { connected: connected2, strategies, draft, loader } = params, strategy = loader.status === "loaded" ? loader.strategy : null, eligibleConfluences = (strategy?.confluences ?? []).filter(
    (c) => isConfluenceEligible(c.directionApplicability, draft.direction)
  );
  return {
    show: connected2,
    strategies,
    selectedStrategyId: draft.strategyId,
    strategyName: strategy?.name ?? null,
    loading: loader.status === "loading",
    loadErrorMessage: loader.status === "error" ? loader.message : null,
    direction: draft.direction,
    sessionNames: strategy?.sessions.map((s) => s.name) ?? [],
    selectedSession: draft.selectedSession,
    entryModels: strategy?.entryModels ?? [],
    selectedEntryModel: draft.selectedEntryModel,
    confluences: eligibleConfluences.map((c) => toRow(c, draft.selectedConfluenceIds)),
    execution: (strategy?.execution ?? []).map((c) => toRow(c, draft.selectedExecutionIds)),
    rules: {
      show: strategy != null && (strategy.frameworkSteps.length > 0 || strategy.tradeManagement != null),
      frameworkStepCount: strategy?.frameworkSteps.length ?? 0,
      frameworkSteps: strategy?.frameworkSteps ?? [],
      tradeManagement: strategy?.tradeManagement ?? null
    },
    validation: validateDraft(draft, strategy?.confluences ?? [], strategy?.entryModels ?? [])
  };
}

// src/panel/trade-submission.ts
function createTradeSubmitter(createTrade, onChange) {
  let pendingKey = null, inFlight = !1, awaitingEditToRotateKey = !1;
  return {
    async submit(payload) {
      if (inFlight) return;
      pendingKey == null && (pendingKey = crypto.randomUUID());
      let key = pendingKey;
      inFlight = !0, onChange({ status: "submitting" });
      let result = await createTrade(payload, key);
      if (inFlight = !1, result.ok) {
        pendingKey = null, awaitingEditToRotateKey = !1, onChange({ status: "success", result });
        return;
      }
      awaitingEditToRotateKey = result.kind === "unauthorized" || result.kind === "conflict" || result.kind === "validation", onChange({ status: "error", result });
    },
    notifyDraftEdited() {
      awaitingEditToRotateKey && (pendingKey = null, awaitingEditToRotateKey = !1);
    },
    reset() {
      pendingKey = null, awaitingEditToRotateKey = !1, inFlight = !1, onChange({ status: "idle" });
    }
  };
}

// src/shared/planned-r.ts
function previewPlannedR(direction, entry, stopLoss, target) {
  let riskDistance = direction === "LONG" ? entry - stopLoss : stopLoss - entry, rewardDistance = direction === "LONG" ? target - entry : entry - target;
  return riskDistance > 0 ? { r: rewardDistance / riskDistance, reason: null } : { r: null, reason: "Stop loss must be on the risk side of entry to preview R." };
}

// src/panel/trade-view.ts
function toSubmissionViewModel(submission, webAppBaseUrl) {
  switch (submission.status) {
    case "idle":
      return { status: "idle" };
    case "submitting":
      return { status: "submitting" };
    case "success": {
      let trade = submission.result.trade;
      return {
        status: "success",
        assetSymbol: trade.assetSymbol,
        direction: trade.direction,
        strategyName: trade.strategyName,
        targetCount: trade.plannedTargets.length,
        hasPlanScreenshot: trade.hasPlanScreenshot,
        warnings: submission.result.warnings,
        viewUrl: `${webAppBaseUrl}/journal/${trade.dateKey}/trades/${trade.id}`
      };
    }
    case "error": {
      let { result } = submission;
      return { status: "error", message: result.message, issues: result.kind === "validation" ? result.issues : [] };
    }
  }
}
function toTradeViewModel(params) {
  let { draft, chartContext, strategy, submission, webAppBaseUrl } = params, payloadResult = buildCreateTradePayload({ draft, chartContext, strategy }), entryNum = Number(draft.plannedEntry.trim()), stopNum = Number(draft.plannedStopLoss.trim()), canPreviewR = draft.direction != null && draft.plannedEntry.trim().length > 0 && draft.plannedStopLoss.trim().length > 0 && Number.isFinite(entryNum) && Number.isFinite(stopNum), targets = draft.plannedTargets.map((t) => {
    let rPreviewText = null, targetNum = Number(t.targetPrice.trim());
    if (canPreviewR && draft.direction && t.targetPrice.trim().length > 0 && Number.isFinite(targetNum)) {
      let preview = previewPlannedR(draft.direction, entryNum, stopNum, targetNum);
      preview.r != null && (rPreviewText = `${preview.r.toFixed(1)}R`);
    }
    return { id: t.id, label: t.label, targetPrice: t.targetPrice, rPreviewText };
  });
  return {
    plannedEntry: draft.plannedEntry,
    plannedStopLoss: draft.plannedStopLoss,
    targets,
    marketContext: draft.marketContext,
    areasOfInterest: draft.areasOfInterest,
    reasonForTrade: draft.reasonForTrade,
    canSave: payloadResult.payload != null && submission.status !== "submitting",
    blockerMessages: payloadResult.blockers.map((b) => b.message),
    warningMessages: payloadResult.warnings,
    submission: toSubmissionViewModel(submission, webAppBaseUrl)
  };
}

// src/panel/screenshot.ts
function createScreenshotController(fns, onChange) {
  let state = { status: "idle" }, generation = 0, captureInFlight = !1, uploadInFlight = !1;
  function set(next) {
    state = next, onChange(next);
  }
  async function doCapture() {
    if (captureInFlight) return;
    captureInFlight = !0;
    let myGeneration = ++generation;
    set({ status: "capturing" });
    let result = await fns.capture();
    captureInFlight = !1, myGeneration === generation && set(result.ok ? { status: "captured", dataUrl: result.dataUrl } : { status: "capture_error", message: result.message });
  }
  async function doUpload() {
    if (uploadInFlight || state.status !== "captured" && state.status !== "upload_error") return;
    let dataUrl = state.dataUrl, myGeneration = generation;
    uploadInFlight = !0, set({ status: "uploading", dataUrl });
    let result = await fns.upload(dataUrl);
    uploadInFlight = !1, myGeneration === generation && set(result.ok ? { status: "uploaded", dataUrl, mediaAssetId: result.mediaAssetId } : { status: "upload_error", dataUrl, message: result.message });
  }
  return {
    capture: () => void doCapture(),
    retake: () => void doCapture(),
    upload: () => void doUpload(),
    remove: () => {
      generation++, set({ status: "idle" });
    }
  };
}

// src/panel/recognition.ts
function createRecognitionController(analyze, onChange) {
  let inFlight = !1;
  return {
    analyze(mediaAssetId) {
      inFlight || (inFlight = !0, onChange({ status: "analyzing" }), analyze(mediaAssetId).then((result) => {
        inFlight = !1, onChange(result.ok ? { status: "analyzed", outcome: result.outcome } : { status: "error", message: result.message });
      }));
    },
    dismiss() {
      onChange({ status: "idle" });
    }
  };
}

// src/panel/panel.ts
function el(role) {
  let found = document.querySelector(`[data-role="${role}"]`);
  if (!found) throw new Error(`Missing panel element: ${role}`);
  return found;
}
function sendRaw(message) {
  return chrome.runtime.sendMessage(message);
}
function sendMessage(message) {
  return sendRaw(message);
}
function setSection(name) {
  for (let section of ["disconnected-view", "connect-form", "connecting-view", "error-view", "connected-view"])
    el(section).hidden = section !== name;
}
var currentDraft = EMPTY_DRAFT, currentStrategies = [], currentChartContext = null, connected = !1, tvDetected = !1, loaderState = { status: "idle" }, submissionState = { status: "idle" }, screenshotState = { status: "idle" }, recognitionState = { status: "idle" }, rulesExpanded = !1, notesExpanded = !0;
function currentSymbolDisplay() {
  return currentChartContext?.symbol?.display ?? null;
}
var strategyLoader = createStrategyLoader(
  (strategyId) => sendRaw({ type: "GET_STRATEGY_REFERENCE", strategyId }),
  (state) => {
    loaderState = state, renderStrategySection(), renderTradeSection();
  }
), tradeSubmitter = createTradeSubmitter(
  (payload, idempotencyKey) => sendRaw({ type: "CREATE_TRADE", payload, idempotencyKey }),
  (state) => {
    submissionState = state, state.status === "success" ? applyDraft(resetAfterSave(currentDraft)) : renderTradeSection();
  }
), screenshotController = createScreenshotController(
  {
    capture: async () => {
      let result = await sendRaw({ type: "CAPTURE_CHART" });
      return result.ok ? { ok: !0, dataUrl: result.dataUrl } : { ok: !1, message: result.message };
    },
    upload: async (dataUrl) => {
      let result = await sendRaw({ type: "UPLOAD_CAPTURE", dataUrl, fileName: "chart.png" });
      return result.ok ? { ok: !0, mediaAssetId: result.media.id } : { ok: !1, message: result.message };
    }
  },
  (state) => {
    screenshotState = state, state.status === "uploaded" ? applyDraft(setMediaAssetId(currentDraft, state.mediaAssetId)) : renderScreenshotSection();
  }
), recognitionController = createRecognitionController(
  async (mediaAssetId) => {
    let result = await sendRaw({ type: "ANALYZE_SCREENSHOT", mediaAssetId });
    return result.ok ? { ok: !0, outcome: result.outcome } : { ok: !1, message: result.message };
  },
  (state) => {
    recognitionState = state, renderScreenshotSection();
  }
);
function confluencesById() {
  let strategy = loaderState.status === "loaded" ? loaderState.strategy : null;
  return new Map((strategy?.confluences ?? []).map((c) => [c.id, { directionApplicability: c.directionApplicability }]));
}
function currentStrategyReference() {
  return loaderState.status === "loaded" ? loaderState.strategy : null;
}
async function applyDraft(next) {
  tradeSubmitter.notifyDraftEdited(), currentDraft = next, renderStrategySection(), renderTradeSection(), renderScreenshotSection(), renderSymbolWarning(), await sendRaw({ type: "SET_DRAFT", draft: next });
}
function renderConfluenceRow(row) {
  let label = document.createElement("label");
  label.className = "tag-row";
  let checkbox = document.createElement("input");
  checkbox.type = "checkbox", checkbox.checked = row.checked, checkbox.dataset.confluenceId = row.id;
  let text = document.createElement("span");
  text.className = "tag-row-text";
  let name = document.createElement("span");
  name.className = "tag-row-name", name.textContent = row.name;
  let meta = document.createElement("span");
  meta.className = row.mandatory ? "tag-row-meta mandatory" : "tag-row-meta";
  let parts = [row.mandatory ? "Mandatory" : "Optional"];
  return row.weight != null && parts.push(`Weight ${row.weight}`), meta.textContent = parts.join(" \xB7 "), text.append(name, meta), label.append(checkbox, text), label;
}
function renderRowList(containerRole, rows) {
  el(containerRole).replaceChildren(...rows.map(renderConfluenceRow));
}
function option(value, label) {
  let opt = document.createElement("option");
  return opt.value = value, opt.textContent = label, opt;
}
function renderOptions(select, values, selected, placeholder) {
  select.replaceChildren(option("", placeholder), ...values.map((v) => option(v, v))), select.value = selected ?? "";
}
function renderSymbolWarning() {
  let current = currentSymbolDisplay(), origin = currentDraft.originSymbol, show = origin != null && current != null && origin !== current && currentDraft.acknowledgedSymbolMismatch !== current, card = el("symbol-warning");
  card.hidden = !show, show && (el("symbol-warning-text").textContent = `This Trade Idea was started for ${origin}. Current chart is ${current}.`, el("keep-draft").textContent = `Keep ${origin} Draft`, el("start-new-idea").textContent = `Start New ${current} Idea`);
}
function renderStrategySection() {
  let vm = toStrategyContextViewModel({ connected, strategies: currentStrategies, draft: currentDraft, loader: loaderState }), card = el("strategy-card");
  if (card.hidden = !vm.show, !vm.show) return;
  let select = el("strategy-select");
  document.activeElement !== select && (select.replaceChildren(option("", "Select a strategy\u2026"), ...vm.strategies.map((s) => option(s.id, s.name))), select.value = vm.selectedStrategyId ?? ""), el("strategy-loading").hidden = !vm.loading;
  let loadError = el("strategy-load-error");
  loadError.hidden = vm.loadErrorMessage == null, loadError.textContent = vm.loadErrorMessage ?? "";
  let detail = el("strategy-detail");
  if (detail.hidden = vm.selectedStrategyId == null, vm.selectedStrategyId == null) return;
  let isLong = vm.direction === "LONG", isShort = vm.direction === "SHORT";
  el("direction-long").dataset.active = String(isLong), el("direction-long").setAttribute("aria-pressed", String(isLong)), el("direction-short").dataset.active = String(isShort), el("direction-short").setAttribute("aria-pressed", String(isShort));
  let sessionField = el("session-field");
  sessionField.hidden = vm.sessionNames.length === 0, vm.sessionNames.length > 0 && renderOptions(el("session-select"), vm.sessionNames, vm.selectedSession, "\u2014");
  let entryModelField = el("entry-model-field");
  entryModelField.hidden = vm.entryModels.length === 0, vm.entryModels.length > 0 && renderOptions(el("entry-model-select"), vm.entryModels, vm.selectedEntryModel, "\u2014"), el("confluences-field").hidden = vm.confluences.length === 0, renderRowList("confluence-list", vm.confluences), el("execution-field").hidden = vm.execution.length === 0, renderRowList("execution-list", vm.execution);
  let rules = el("strategy-rules");
  if (rules.hidden = !vm.rules.show, vm.rules.show) {
    el("rules-content").hidden = !rulesExpanded, el("toggle-rules").setAttribute("aria-expanded", String(rulesExpanded)), el("rules-framework").textContent = vm.rules.frameworkStepCount > 0 ? `Framework \u2014 ${vm.rules.frameworkStepCount} steps: ${vm.rules.frameworkSteps.join(", ")}` : "";
    let tm = vm.rules.tradeManagement;
    el("rules-trade-management").textContent = tm ? [
      tm.maxRiskPercent != null ? `Max risk ${tm.maxRiskPercent}%` : null,
      tm.maxHoldingTime ? `Max hold ${tm.maxHoldingTime}` : null,
      ...tm.customRules
    ].filter((x) => x != null).join(" \xB7 ") : "Trade management \u2014 not configured.";
  }
  let hints = [];
  vm.validation.strategyRequired && hints.push("Strategy required"), vm.validation.directionRequired && hints.push("Direction required"), vm.validation.entryModelRequired && hints.push("Entry model required"), vm.validation.missingMandatoryConfluenceIds.length > 0 && hints.push("Mandatory confluence not selected"), el("validation-hints").textContent = hints.join(" \xB7 ");
}
function renderTargetList(rows) {
  let container = el("target-list"), existingIds = Array.from(container.children).map((c) => c.dataset.targetId), nextIds = rows.map((r) => r.id);
  if (!(existingIds.length === nextIds.length && existingIds.every((id, i) => id === nextIds[i]))) {
    container.replaceChildren(...rows.map(renderTargetRow));
    return;
  }
  rows.forEach((row, i) => {
    let rowEl = container.children[i], priceInput = rowEl.querySelector(".target-price-input");
    document.activeElement !== priceInput && (priceInput.value = row.targetPrice), rowEl.querySelector(".target-label").textContent = row.label, rowEl.querySelector(".target-r-preview").textContent = row.rPreviewText ?? "";
  });
}
function renderTargetRow(row) {
  let div = document.createElement("div");
  div.className = "target-row", div.dataset.targetId = row.id;
  let label = document.createElement("span");
  label.className = "target-label", label.textContent = row.label;
  let input = document.createElement("input");
  input.type = "text", input.inputMode = "decimal", input.autocomplete = "off", input.className = "target-price-input", input.value = row.targetPrice, input.addEventListener("input", () => {
    applyDraft(updateTarget(currentDraft, row.id, { targetPrice: input.value }));
  });
  let preview = document.createElement("span");
  preview.className = "target-r-preview", preview.textContent = row.rPreviewText ?? "";
  let remove = document.createElement("button");
  return remove.type = "button", remove.className = "target-remove", remove.textContent = "\xD7", remove.setAttribute("aria-label", "Remove target"), remove.addEventListener("click", () => void applyDraft(removeTarget(currentDraft, row.id))), div.append(label, input, preview, remove), div;
}
function setValueUnlessFocused(input, value) {
  document.activeElement !== input && (input.value = value);
}
function renderTradeSection() {
  let show = connected && tvDetected, card = el("trade-plan-card");
  if (card.hidden = !show, !show) return;
  let vm = toTradeViewModel({
    draft: currentDraft,
    chartContext: currentChartContext,
    strategy: currentStrategyReference(),
    submission: submissionState,
    webAppBaseUrl: API_BASE_URL
  });
  setValueUnlessFocused(el("entry-input"), vm.plannedEntry), setValueUnlessFocused(el("stop-input"), vm.plannedStopLoss), renderTargetList(vm.targets), setValueUnlessFocused(el("market-context-input"), vm.marketContext), setValueUnlessFocused(el("areas-of-interest-input"), vm.areasOfInterest), setValueUnlessFocused(el("reason-for-trade-input"), vm.reasonForTrade);
  let warningsEl = el("trade-warnings");
  warningsEl.hidden = vm.warningMessages.length === 0, warningsEl.textContent = vm.warningMessages.join(" \xB7 ");
  let blockersEl = el("trade-blockers"), showBlockers = vm.blockerMessages.length > 0 && vm.submission.status !== "success";
  blockersEl.hidden = !showBlockers, blockersEl.textContent = vm.blockerMessages.join(" \xB7 ");
  let saveBtn = el("save-trade");
  if (saveBtn.disabled = !vm.canSave, saveBtn.hidden = vm.submission.status === "success", saveBtn.textContent = vm.submission.status === "submitting" ? "Saving\u2026" : "Save Trade Idea", el("notes-content").hidden = !notesExpanded, el("toggle-notes").textContent = notesExpanded ? "Notes \u25B4" : "Notes \u25BE", el("toggle-notes").setAttribute("aria-expanded", String(notesExpanded)), el("trade-success").hidden = vm.submission.status !== "success", el("trade-error").hidden = vm.submission.status !== "error", vm.submission.status === "success") {
    let s = vm.submission;
    el("success-summary").textContent = `${s.assetSymbol} \xB7 ${s.direction}${s.strategyName ? ` \xB7 ${s.strategyName}` : ""} \xB7 ${s.targetCount} target${s.targetCount === 1 ? "" : "s"}${s.hasPlanScreenshot ? " \xB7 Screenshot attached" : ""}`;
    let warnEl = el("success-warnings");
    warnEl.hidden = s.warnings.length === 0, warnEl.textContent = s.warnings.length > 0 ? `Saved with warning: ${s.warnings.join(" ")}` : "", el("view-in-traditorium").href = s.viewUrl;
  } else vm.submission.status === "error" && (el("error-summary").textContent = vm.submission.message, el("error-issues").replaceChildren(
    ...vm.submission.issues.map((issue) => {
      let li = document.createElement("li");
      return li.textContent = `${issue.path}: ${issue.message}`, li;
    })
  ));
}
function screenshotDataUrl(state) {
  switch (state.status) {
    case "captured":
    case "uploading":
    case "uploaded":
    case "upload_error":
      return state.dataUrl;
    default:
      return null;
  }
}
function renderScreenshotSection() {
  let show = connected && tvDetected, card = el("screenshot-card");
  if (card.hidden = !show, !show) return;
  let state = screenshotState;
  el("capture-chart").hidden = !(state.status === "idle" || state.status === "capture_error"), el("screenshot-capturing").hidden = state.status !== "capturing";
  let dataUrl = screenshotDataUrl(state), previewEl = el("screenshot-preview");
  if (previewEl.hidden = dataUrl == null, dataUrl) {
    el("screenshot-image").src = dataUrl;
    let uploadBtn = el("upload-screenshot");
    uploadBtn.hidden = state.status === "uploading" || state.status === "uploaded", uploadBtn.disabled = state.status === "uploading", uploadBtn.textContent = state.status === "upload_error" ? "Try Upload Again" : "Upload Screenshot";
    let statusEl = el("screenshot-status");
    switch (state.status) {
      case "captured":
        statusEl.textContent = "Not uploaded yet.";
        break;
      case "uploading":
        statusEl.textContent = "Uploading\u2026";
        break;
      case "uploaded":
        statusEl.textContent = "\u2713 Uploaded";
        break;
      case "upload_error":
        statusEl.textContent = "";
        break;
    }
  }
  let errorEl = el("screenshot-error"), hasError = state.status === "capture_error" || state.status === "upload_error";
  errorEl.hidden = !hasError, hasError && (errorEl.textContent = state.message);
  let uploaded = state.status === "uploaded";
  el("analyze-idle").hidden = !(uploaded && recognitionState.status === "idle"), el("recognition-analyzing").hidden = !(uploaded && recognitionState.status === "analyzing");
  let recognitionErrorEl = el("recognition-error");
  recognitionErrorEl.hidden = !(uploaded && recognitionState.status === "error"), uploaded && recognitionState.status === "error" && (recognitionErrorEl.textContent = recognitionState.message);
  let resultEl = el("recognition-result");
  resultEl.hidden = !(uploaded && recognitionState.status === "analyzed"), uploaded && recognitionState.status === "analyzed" && renderRecognitionResult(toPlanSuggestion(recognitionState.outcome));
}
function recognitionFieldRow(label, value) {
  let dt = document.createElement("dt");
  dt.textContent = label;
  let dd = document.createElement("dd");
  return value != null ? dd.textContent = value : (dd.textContent = "Not detected", dd.className = "not-detected"), [dt, dd];
}
function buildRecognitionFieldRows(suggestion) {
  let rows = [], push = (label, value) => rows.push(...recognitionFieldRow(label, value));
  if (push("Entry", suggestion.entry), push("Stop", suggestion.stopLoss), suggestion.targets.length === 0)
    push("Targets", null);
  else
    for (let target of suggestion.targets) push(`TP${target.order}`, target.price);
  return rows;
}
function describeContextConflict(suggestion) {
  let parts = [], currentSymbol = currentSymbolDisplay();
  suggestion.symbol && currentSymbol && suggestion.symbol !== currentSymbol && parts.push(`symbol ${suggestion.symbol} (chart shows ${currentSymbol})`);
  let currentTimeframe = currentChartContext?.timeframe ?? null;
  return suggestion.timeframe && currentTimeframe && suggestion.timeframe !== currentTimeframe && parts.push(`timeframe ${suggestion.timeframe} (chart shows ${currentTimeframe})`), suggestion.direction && currentDraft.direction && suggestion.direction !== currentDraft.direction && parts.push(`direction ${suggestion.direction} (you selected ${currentDraft.direction})`), parts.length === 0 ? null : `Recognition detected a different ${parts.join(", ")} \u2014 your chart/selection is kept; Apply only updates the plan prices/targets below.`;
}
function renderRecognitionResult(suggestion) {
  el("recognition-empty").hidden = !suggestion.isEmpty;
  let fieldsEl = el("recognition-fields");
  fieldsEl.hidden = suggestion.isEmpty, suggestion.isEmpty || fieldsEl.replaceChildren(...buildRecognitionFieldRows(suggestion));
  let conflictText = describeContextConflict(suggestion), conflictEl = el("recognition-context-conflict");
  conflictEl.hidden = conflictText == null, conflictEl.textContent = conflictText ?? "";
  let hasExistingPlanValues = currentDraft.plannedEntry.trim().length > 0 || currentDraft.plannedStopLoss.trim().length > 0 || currentDraft.plannedTargets.length > 0;
  el("recognition-overwrite-warning").hidden = !hasExistingPlanValues, el("apply-suggestions").hidden = suggestion.isEmpty;
}
function render(state) {
  let vm = toViewModel(state);
  el("tv-dot").dataset.state = vm.tvOn ? "on" : "off", el("tv-label").textContent = vm.tvLabel;
  let connRow = el("conn-row");
  connRow.hidden = !vm.showConnRow, el("conn-dot").dataset.state = vm.connState, el("conn-label").textContent = vm.connLabel, el("chart-card").hidden = !vm.chart.show, el("chart-values").hidden = vm.chart.unavailableLabel != null, el("chart-symbol").textContent = vm.chart.symbolText ?? "", el("chart-timeframe").textContent = vm.chart.timeframeText ?? "";
  let chartUnavailable = el("chart-unavailable");
  chartUnavailable.hidden = vm.chart.unavailableLabel == null, chartUnavailable.textContent = vm.chart.unavailableLabel ?? "", setSection(
    vm.section === "disconnected" ? "disconnected-view" : vm.section === "connecting" ? "connecting-view" : vm.section === "error" ? "error-view" : "connected-view"
  ), vm.section === "connected" && (el("user-name").textContent = vm.userName, el("strategy-count").textContent = vm.strategyCountLabel), vm.section === "error" && (el("error-message").textContent = vm.errorMessage), el("footer").hidden = !vm.showFooter, connected = vm.section === "connected", tvDetected = vm.tvOn, currentStrategies = vm.strategies, currentChartContext = state.chartContext;
  let draftWithOrigin = ensureOriginSymbol(state.draft, currentSymbolDisplay());
  currentDraft = draftWithOrigin, draftWithOrigin !== state.draft && applyDraft(draftWithOrigin), currentDraft.strategyId && loaderState.status === "idle" && strategyLoader.request(currentDraft.strategyId), renderStrategySection(), renderTradeSection(), renderScreenshotSection(), renderSymbolWarning();
}
async function refresh() {
  render(await sendMessage({ type: "GET_STATE" }));
}
function wireStrategyEvents() {
  el("strategy-select").addEventListener("change", (e) => {
    let id = e.target.value || null;
    strategyLoader.request(id), applyDraft(selectStrategy(currentDraft, id));
  });
  let setDirectionTo = (direction) => {
    applyDraft(setDirection(currentDraft, currentDraft.direction === direction ? null : direction, confluencesById()));
  };
  el("direction-long").addEventListener("click", () => setDirectionTo("LONG")), el("direction-short").addEventListener("click", () => setDirectionTo("SHORT")), el("session-select").addEventListener("change", (e) => {
    applyDraft(setSession(currentDraft, e.target.value || null));
  }), el("entry-model-select").addEventListener("change", (e) => {
    applyDraft(setEntryModel(currentDraft, e.target.value || null));
  }), el("confluence-list").addEventListener("change", (e) => {
    let id = e.target.dataset.confluenceId;
    id && applyDraft(toggleConfluence(currentDraft, id));
  }), el("execution-list").addEventListener("change", (e) => {
    let id = e.target.dataset.confluenceId;
    id && applyDraft(toggleExecution(currentDraft, id));
  }), el("toggle-rules").addEventListener("click", () => {
    rulesExpanded = !rulesExpanded, renderStrategySection();
  });
}
function attemptSave() {
  let result = buildCreateTradePayload({ draft: currentDraft, chartContext: currentChartContext, strategy: currentStrategyReference() });
  result.payload && tradeSubmitter.submit(result.payload);
}
function wireTradeEvents() {
  el("entry-input").addEventListener("input", (e) => {
    applyDraft(setPlannedEntry(currentDraft, e.target.value));
  }), el("stop-input").addEventListener("input", (e) => {
    applyDraft(setPlannedStopLoss(currentDraft, e.target.value));
  }), el("add-target").addEventListener("click", () => void applyDraft(addTarget(currentDraft))), el("toggle-notes").addEventListener("click", () => {
    notesExpanded = !notesExpanded, renderTradeSection();
  });
  let noteFields = [
    ["market-context-input", "marketContext"],
    ["areas-of-interest-input", "areasOfInterest"],
    ["reason-for-trade-input", "reasonForTrade"]
  ];
  for (let [role, field] of noteFields)
    el(role).addEventListener("input", (e) => {
      applyDraft(setNote(currentDraft, field, e.target.value));
    });
  el("save-trade").addEventListener("click", attemptSave), el("retry-save").addEventListener("click", attemptSave), el("add-another").addEventListener("click", () => {
    tradeSubmitter.reset(), applyDraft(resetAfterSave(currentDraft));
  });
}
function cleanupOrphanedMedia(mediaAssetId) {
  sendRaw({ type: "DELETE_MEDIA", mediaAssetId });
}
function clearMediaAssetIdIfSet() {
  let orphanedId = currentDraft.mediaAssetId;
  orphanedId != null && (applyDraft(setMediaAssetId(currentDraft, null)), cleanupOrphanedMedia(orphanedId));
}
function wireScreenshotEvents() {
  el("capture-chart").addEventListener("click", () => {
    clearMediaAssetIdIfSet(), screenshotController.capture();
  }), el("retake-screenshot").addEventListener("click", () => {
    clearMediaAssetIdIfSet(), screenshotController.retake(), recognitionController.dismiss();
  }), el("upload-screenshot").addEventListener("click", () => screenshotController.upload()), el("remove-screenshot").addEventListener("click", () => {
    screenshotController.remove(), clearMediaAssetIdIfSet(), recognitionController.dismiss();
  }), el("analyze-chart").addEventListener("click", () => {
    currentDraft.mediaAssetId && recognitionController.analyze(currentDraft.mediaAssetId);
  }), el("dismiss-suggestions").addEventListener("click", () => recognitionController.dismiss()), el("apply-suggestions").addEventListener("click", () => {
    if (recognitionState.status !== "analyzed") return;
    let suggestion = toPlanSuggestion(recognitionState.outcome);
    applyDraft(applyPlanSuggestion(currentDraft, suggestion)), recognitionController.dismiss();
  });
}
function wireSymbolWarningEvents() {
  el("keep-draft").addEventListener("click", () => {
    applyDraft(acknowledgeSymbolMismatch(currentDraft, currentSymbolDisplay()));
  }), el("start-new-idea").addEventListener("click", () => {
    let orphanedMediaAssetId = currentDraft.mediaAssetId;
    screenshotController.remove(), recognitionController.dismiss(), tradeSubmitter.reset(), applyDraft(startNewIdeaForSymbol(currentDraft, currentSymbolDisplay())), orphanedMediaAssetId != null && cleanupOrphanedMedia(orphanedMediaAssetId);
  });
}
function wireEvents() {
  el("show-connect-form").addEventListener("click", () => setSection("connect-form")), el("cancel-connect").addEventListener("click", () => setSection("disconnected-view"));
  let submitToken = async () => {
    let input = el("token-input"), token = input.value;
    input.value = "", setSection("connecting-view"), render(await sendMessage({ type: "CONNECT", token }));
  };
  el("submit-token").addEventListener("click", submitToken), el("token-input").addEventListener("keydown", (e) => {
    e.key === "Enter" && submitToken();
  }), el("retry-connect").addEventListener("click", () => setSection("connect-form")), el("disconnect").addEventListener("click", async () => {
    render(await sendMessage({ type: "DISCONNECT" }));
  }), wireStrategyEvents(), wireTradeEvents(), wireScreenshotEvents(), wireSymbolWarningEvents();
  for (let anchor of document.querySelectorAll('[data-role="open-settings"]'))
    anchor.href = `${API_BASE_URL}/settings/integrations`;
}
wireEvents();
refresh();
window.addEventListener("focus", () => void refresh());
chrome.runtime.onMessage.addListener((message) => {
  message.type === "CHART_CONTEXT_CHANGED" && refresh();
});
