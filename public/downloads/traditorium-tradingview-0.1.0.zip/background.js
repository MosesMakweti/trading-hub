// src/shared/draft.ts
var EMPTY_DRAFT = {
  strategyId: null,
  direction: null,
  selectedSession: null,
  selectedEntryModel: null,
  selectedConfluenceIds: [],
  selectedExecutionIds: [],
  plannedEntry: "",
  plannedStopLoss: "",
  plannedTargets: [],
  marketContext: "",
  areasOfInterest: "",
  reasonForTrade: "",
  mediaAssetId: null,
  originSymbol: null,
  acknowledgedSymbolMismatch: null,
  updatedAt: 0
};

// src/background/draft-storage.ts
var STORAGE_KEY = "traditorium_draft";
async function getDraft() {
  return (await chrome.storage.session.get(STORAGE_KEY))[STORAGE_KEY] ?? EMPTY_DRAFT;
}
async function setDraft(draft) {
  await chrome.storage.session.set({ [STORAGE_KEY]: draft });
}

// src/shared/config.ts
var API_BASE_URL = "https://traditorium.com";

// src/background/api-client.ts
async function request(path, token) {
  let res;
  try {
    res = await fetch(`${API_BASE_URL}${path}`, {
      method: "GET",
      headers: { Authorization: `Bearer ${token}` }
    });
  } catch {
    return { ok: !1, reason: "network", message: "Could not reach Traditorium." };
  }
  if (res.status === 401)
    return { ok: !1, reason: "unauthorized", message: "The Traditorium token is invalid or has been revoked." };
  if (!res.ok)
    return { ok: !1, reason: "server", message: `Traditorium returned an unexpected error (${res.status}).` };
  try {
    return { ok: !0, data: await res.json() };
  } catch {
    return { ok: !1, reason: "malformed", message: "Traditorium sent an unexpected response." };
  }
}
function getMe(token) {
  return request("/api/v1/me", token);
}
function getStrategies(token) {
  return request("/api/v1/strategies", token);
}
function getStrategy(token, id) {
  return request(`/api/v1/strategies/${encodeURIComponent(id)}`, token);
}
async function createTrade(token, payload, idempotencyKey) {
  let res;
  try {
    res = await fetch(`${API_BASE_URL}/api/v1/trades`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
        "Idempotency-Key": idempotencyKey
      },
      body: JSON.stringify(payload)
    });
  } catch {
    return { ok: !1, kind: "network", message: "Could not reach Traditorium." };
  }
  let body;
  try {
    body = await res.json();
  } catch {
    return { ok: !1, kind: "server", message: "Traditorium sent an unexpected response." };
  }
  if (res.status === 200 || res.status === 201) {
    let parsed = body;
    return { ok: !0, trade: parsed.trade, warnings: parsed.warnings ?? [], replayed: parsed.replayed ?? !1 };
  }
  if (res.status === 401)
    return { ok: !1, kind: "unauthorized", message: errorMessageOf(body, "The Traditorium token is invalid or has been revoked.") };
  if (res.status === 409)
    return { ok: !1, kind: "conflict", message: errorMessageOf(body, "This request conflicts with a previous submission.") };
  if (res.status === 422) {
    let parsed = body;
    return { ok: !1, kind: "validation", message: parsed.error ?? "Validation failed.", issues: parsed.issues ?? [] };
  }
  return { ok: !1, kind: "server", message: `Traditorium returned an unexpected error (${res.status}).` };
}
async function uploadMedia(token, bytes, mimeType, fileName) {
  let form = new FormData();
  form.set("file", new Blob([bytes], { type: mimeType }), fileName);
  let res;
  try {
    res = await fetch(`${API_BASE_URL}/api/v1/media`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}` },
      // no Content-Type — fetch sets the multipart boundary itself
      body: form
    });
  } catch {
    return { ok: !1, kind: "network", message: "Could not reach Traditorium." };
  }
  let body;
  try {
    body = await res.json();
  } catch {
    return { ok: !1, kind: "server", message: "Traditorium sent an unexpected response." };
  }
  return res.status === 201 ? { ok: !0, media: body } : res.status === 401 ? { ok: !1, kind: "unauthorized", message: errorMessageOf(body, "The Traditorium token is invalid or has been revoked.") } : res.status === 415 ? { ok: !1, kind: "unsupported_type", message: errorMessageOf(body, "Unsupported image format.") } : res.status === 413 ? { ok: !1, kind: "too_large", message: errorMessageOf(body, "Image is too large.") } : res.status === 400 || res.status === 422 ? { ok: !1, kind: "validation", message: errorMessageOf(body, "Could not upload the image.") } : { ok: !1, kind: "server", message: `Traditorium returned an unexpected error (${res.status}).` };
}
async function analyzeScreenshot(token, mediaAssetId) {
  let res;
  try {
    res = await fetch(`${API_BASE_URL}/api/v1/media/${encodeURIComponent(mediaAssetId)}/recognize-trade-plan`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}` }
    });
  } catch {
    return { ok: !1, kind: "network", message: "Could not reach Traditorium." };
  }
  let body;
  try {
    body = await res.json();
  } catch {
    return { ok: !1, kind: "server", message: "Traditorium sent an unexpected response." };
  }
  return res.status === 200 ? { ok: !0, outcome: body } : res.status === 401 ? { ok: !1, kind: "unauthorized", message: errorMessageOf(body, "The Traditorium token is invalid or has been revoked.") } : res.status === 404 ? { ok: !1, kind: "not_found", message: errorMessageOf(body, "Image not found or access denied.") } : { ok: !1, kind: "server", message: `Traditorium returned an unexpected error (${res.status}).` };
}
async function deleteMedia(token, mediaAssetId) {
  let res;
  try {
    res = await fetch(`${API_BASE_URL}/api/v1/media/${encodeURIComponent(mediaAssetId)}`, {
      method: "DELETE",
      headers: { Authorization: `Bearer ${token}` }
    });
  } catch {
    return { ok: !1, kind: "network", message: "Could not reach Traditorium." };
  }
  if (res.status === 204) return { ok: !0 };
  let body;
  try {
    body = await res.json();
  } catch {
    return { ok: !1, kind: "server", message: "Traditorium sent an unexpected response." };
  }
  return res.status === 401 ? { ok: !1, kind: "unauthorized", message: errorMessageOf(body, "The Traditorium token is invalid or has been revoked.") } : res.status === 404 ? { ok: !1, kind: "not_found", message: errorMessageOf(body, "Image not found or already deleted.") } : res.status === 409 ? {
    ok: !1,
    kind: "protected",
    message: errorMessageOf(body, "This image is already attached to a trade and can't be deleted here.")
  } : { ok: !1, kind: "server", message: `Traditorium returned an unexpected error (${res.status}).` };
}
function errorMessageOf(body, fallback) {
  return typeof body == "object" && body !== null && "error" in body && typeof body.error == "string" ? body.error : fallback;
}

// src/background/storage.ts
var STORAGE_KEY2 = "traditorium", EMPTY = { apiToken: null, cachedUser: null, cachedStrategies: null };
async function getStored() {
  return (await chrome.storage.local.get(STORAGE_KEY2))[STORAGE_KEY2] ?? EMPTY;
}
async function setStored(patch) {
  let current = await getStored();
  await chrome.storage.local.set({ [STORAGE_KEY2]: { ...current, ...patch } });
}
async function clearStored() {
  await chrome.storage.local.remove(STORAGE_KEY2);
}

// src/background/state.ts
var TRADINGVIEW_ORIGIN = /^https:\/\/www\.tradingview\.com\//;
async function getActiveTradingViewTab() {
  let [tab] = await chrome.tabs.query({ active: !0, currentWindow: !0 });
  return !tab?.id || !tab.url || !TRADINGVIEW_ORIGIN.test(tab.url) ? null : tab;
}
async function getActiveTradingViewTabId() {
  return (await getActiveTradingViewTab())?.id ?? null;
}
async function verifyAndRefresh() {
  let { apiToken } = await getStored();
  if (!apiToken) return { status: "disconnected" };
  let me = await getMe(apiToken);
  if (!me.ok)
    return me.reason === "unauthorized" && await clearStored(), { status: "error", message: me.message };
  let strategies = await getStrategies(apiToken), strategyList = strategies.ok ? strategies.data.strategies : [];
  return await setStored({ cachedUser: me.data.user, cachedStrategies: strategyList }), { status: "connected", user: me.data.user, strategies: strategyList };
}
async function getConnectionState() {
  let { apiToken } = await getStored();
  return apiToken ? verifyAndRefresh() : { status: "disconnected" };
}
async function connect(token) {
  let trimmed = token.trim();
  return trimmed ? (await setStored({ apiToken: trimmed }), verifyAndRefresh()) : { status: "error", message: "Enter a Traditorium API token." };
}
async function disconnect() {
  return await clearStored(), { status: "disconnected" };
}
async function isActiveTabTradingView() {
  return await getActiveTradingViewTabId() != null;
}
async function fetchStrategyReference(strategyId) {
  let { apiToken } = await getStored();
  if (!apiToken) return { ok: !1, reason: "disconnected", message: "Not connected to Traditorium." };
  let result = await getStrategy(apiToken, strategyId);
  return result.ok ? { ok: !0, strategy: result.data.strategy } : result;
}
async function fetchChartContext() {
  let tabId = await getActiveTradingViewTabId();
  if (tabId == null) return null;
  let message = { type: "GET_CHART_CONTEXT" };
  try {
    return await chrome.tabs.sendMessage(tabId, message) ?? null;
  } catch {
    return null;
  }
}
async function submitCreateTrade(payload, idempotencyKey) {
  let { apiToken } = await getStored();
  if (!apiToken) return { ok: !1, kind: "unauthorized", message: "Not connected to Traditorium." };
  let result = await createTrade(apiToken, payload, idempotencyKey);
  return !result.ok && result.kind === "unauthorized" && await clearStored(), result;
}
async function captureActiveTradingViewTab() {
  let tab = await getActiveTradingViewTab();
  if (!tab || tab.windowId == null)
    return { ok: !1, reason: "no_tab", message: "Open a TradingView chart tab to capture it." };
  try {
    return { ok: !0, dataUrl: await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" }) };
  } catch {
    return { ok: !1, reason: "capture_failed", message: "Could not capture the chart. Make sure the TradingView tab is visible and try again." };
  }
}
function decodeDataUrl(dataUrl) {
  let match = /^data:([^;]+);base64,(.*)$/.exec(dataUrl);
  if (!match) throw new Error("Invalid capture data.");
  let [, mimeType, base64] = match, binary = atob(base64), bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return { bytes, mimeType };
}
async function uploadCapture(dataUrl, fileName = "chart.png") {
  let { apiToken } = await getStored();
  if (!apiToken) return { ok: !1, kind: "unauthorized", message: "Not connected to Traditorium." };
  let { bytes, mimeType } = decodeDataUrl(dataUrl), result = await uploadMedia(apiToken, bytes, mimeType, fileName);
  return !result.ok && result.kind === "unauthorized" && await clearStored(), result;
}
async function analyzeScreenshotAsset(mediaAssetId) {
  let { apiToken } = await getStored();
  if (!apiToken) return { ok: !1, kind: "unauthorized", message: "Not connected to Traditorium." };
  let result = await analyzeScreenshot(apiToken, mediaAssetId);
  return !result.ok && result.kind === "unauthorized" && await clearStored(), result;
}
var attemptedDeletions = /* @__PURE__ */ new Set();
async function deleteOrphanedMedia(mediaAssetId) {
  if (attemptedDeletions.has(mediaAssetId)) return { ok: !0 };
  attemptedDeletions.add(mediaAssetId);
  let { apiToken } = await getStored();
  if (!apiToken) return { ok: !1, kind: "unauthorized", message: "Not connected to Traditorium." };
  let result = await deleteMedia(apiToken, mediaAssetId);
  return !result.ok && result.kind === "unauthorized" && await clearStored(), result;
}

// src/background/index.ts
chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel?.setPanelBehavior?.({ openPanelOnActionClick: !0 }).catch(() => {
  });
});
async function respondWithState(sendResponse, connectionPromise) {
  let [connection, tradingViewDetected, chartContext, draft] = await Promise.all([
    connectionPromise,
    isActiveTabTradingView(),
    fetchChartContext(),
    // §13 — always a fresh, live read, never a cache
    getDraft()
    // Step 6 — the persisted draft, independent of connection status
  ]);
  sendResponse({ connection, tradingViewDetected, chartContext, draft });
}
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  switch (message.type) {
    case "TRADINGVIEW_DETECTED":
      return sendResponse({ ok: !0 }), !1;
    case "CHART_CONTEXT_CHANGED":
      return sendResponse({ ok: !0 }), !1;
    case "GET_STATE":
      return respondWithState(sendResponse, getConnectionState()), !0;
    // keep the message channel open for the async response
    case "CONNECT":
      return respondWithState(sendResponse, connect(message.token)), !0;
    case "DISCONNECT":
      return respondWithState(sendResponse, disconnect()), !0;
    case "REFRESH_STRATEGIES":
      return respondWithState(sendResponse, verifyAndRefresh()), !0;
    case "GET_STRATEGY_REFERENCE":
      return fetchStrategyReference(message.strategyId).then(sendResponse), !0;
    case "SET_DRAFT":
      return setDraft(message.draft).then(() => sendResponse({ ok: !0 })), !0;
    case "CREATE_TRADE":
      return submitCreateTrade(message.payload, message.idempotencyKey).then(sendResponse), !0;
    case "CAPTURE_CHART":
      return captureActiveTradingViewTab().then(sendResponse), !0;
    case "UPLOAD_CAPTURE":
      return uploadCapture(message.dataUrl, message.fileName).then(sendResponse), !0;
    case "ANALYZE_SCREENSHOT":
      return analyzeScreenshotAsset(message.mediaAssetId).then(sendResponse), !0;
    case "DELETE_MEDIA":
      return deleteOrphanedMedia(message.mediaAssetId).then(sendResponse), !0;
    default:
      return !1;
  }
});
