"use strict";
(() => {
  // src/shared/chart-context.ts
  function chartContextsEqual(a, b) {
    return a.symbol?.raw === b.symbol?.raw && a.timeframe === b.timeframe && a.detected === b.detected && a.symbolSource === b.symbolSource && a.timeframeSource === b.timeframeSource;
  }

  // src/shared/symbol-parser.ts
  function parseTradingViewSymbol(raw) {
    let trimmed = raw.trim(), colonIndex = trimmed.indexOf(":");
    if (colonIndex === -1)
      return { raw: trimmed, display: trimmed, exchange: null };
    let exchange = trimmed.slice(0, colonIndex), display = trimmed.slice(colonIndex + 1);
    return !exchange || !display ? { raw: trimmed, display: trimmed, exchange: null } : { raw: trimmed, display, exchange };
  }

  // src/shared/timeframe-parser.ts
  var SECONDS = /^(\d+)S$/i, DAYS = /^(\d*)D$/i, WEEKS = /^(\d*)W$/i, MONTHS = /^(\d*)M$/i, MINUTES = /^(\d+)$/;
  function withDefaultMultiplier(digits) {
    return digits.length === 0 ? 1 : Number.parseInt(digits, 10);
  }
  function normalizeTradingViewInterval(raw) {
    let trimmed = raw.trim();
    if (trimmed.length === 0) return null;
    let seconds = SECONDS.exec(trimmed);
    if (seconds) return `${seconds[1]}s`;
    let days = DAYS.exec(trimmed);
    if (days) return `${withDefaultMultiplier(days[1])}D`;
    let weeks = WEEKS.exec(trimmed);
    if (weeks) return `${withDefaultMultiplier(weeks[1])}W`;
    let months = MONTHS.exec(trimmed);
    if (months) return `${withDefaultMultiplier(months[1])}M`;
    let minutes = MINUTES.exec(trimmed);
    if (minutes) {
      let n = Number.parseInt(minutes[1], 10);
      return n <= 0 ? null : n % 60 === 0 ? `${n / 60}h` : `${n}m`;
    }
    return null;
  }

  // src/content/chart-detector.ts
  function detectSymbol(env) {
    let urlSymbol = new URLSearchParams(env.location.search).get("symbol");
    if (urlSymbol && urlSymbol.trim().length > 0)
      return { symbol: parseTradingViewSymbol(urlSymbol), source: "url" };
    let titleMatch = /^([A-Z0-9.!_-]+(?::[A-Z0-9.!_-]+)?)(?:\s|$)/.exec(env.document.title.trim());
    if (titleMatch)
      return { symbol: parseTradingViewSymbol(titleMatch[1]), source: "title" };
    let domSymbol = queryFirstText(env.document, ['[aria-label="Change symbol"]']);
    return domSymbol ? { symbol: parseTradingViewSymbol(domSymbol), source: "dom" } : null;
  }
  function detectTimeframe(env) {
    let domInterval = queryFirstText(env.document, ['[aria-label="Change interval"]']);
    if (domInterval) {
      let normalized = normalizeTradingViewInterval(domInterval);
      if (normalized) return { timeframe: normalized, source: "dom" };
    }
    return null;
  }
  function queryFirstText(document2, selectors) {
    for (let selector of selectors)
      try {
        let text = document2.querySelector(selector)?.textContent?.trim();
        if (text) return text;
      } catch {
      }
    return null;
  }
  function detectChartContext(env, now = Date.now) {
    let symbolResult = detectSymbol(env), timeframeResult = detectTimeframe(env);
    return {
      symbol: symbolResult?.symbol ?? null,
      timeframe: timeframeResult?.timeframe ?? null,
      detected: symbolResult != null || timeframeResult != null,
      symbolSource: symbolResult?.source ?? null,
      timeframeSource: timeframeResult?.source ?? null,
      updatedAt: now()
    };
  }

  // src/content/tradingview-detect.ts
  var RECONCILE_INTERVAL_MS = 3e3, lastSent = null;
  function send(message) {
    chrome.runtime.sendMessage(message).catch(() => {
    });
  }
  function reportIfChanged() {
    let context = detectChartContext({ location: window.location, document });
    lastSent && chartContextsEqual(lastSent, context) || (lastSent = context, !1, send({ type: "CHART_CONTEXT_CHANGED", context }));
  }
  function installSpaNavigationHooks() {
    let notify = () => reportIfChanged();
    for (let method of ["pushState", "replaceState"]) {
      let original = history[method];
      history[method] = function(...args) {
        let result = original.apply(this, args);
        return notify(), result;
      };
    }
    window.addEventListener("popstate", notify);
  }
  function installTitleObserver() {
    let titleEl = document.querySelector("title");
    titleEl && new MutationObserver(() => reportIfChanged()).observe(titleEl, { childList: !0, characterData: !0, subtree: !0 });
  }
  var detected = { type: "TRADINGVIEW_DETECTED" };
  send(detected);
  reportIfChanged();
  installTitleObserver();
  installSpaNavigationHooks();
  setInterval(reportIfChanged, RECONCILE_INTERVAL_MS);
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => (message.type === "GET_CHART_CONTEXT" && sendResponse(detectChartContext({ location: window.location, document })), !1));
})();
